<?php
define('HTTP_SERVER', 'http://customer.albertapayments.com/');
define('HTTP_CATALOG', 'http://customer.albertapayments.com/');
// HTTPS
define('HTTPS_SERVER', 'https://customer.albertapayments.com/');
define('HTTPS_CATALOG', 'https://customer.albertapayments.com/');

define('DOMAIN','customer');

define('DIR_APPLICATION', '/home/albertapayments/public_html/customer/');
define('DIR_SYSTEM', '/home/albertapayments/public_html/customer/system/');
define('DIR_IMAGE', '/home/albertapayments/public_html/customer/image/');
define('DIR_LANGUAGE', '/home/albertapayments/public_html/customer/language/');
define('DIR_TEMPLATE', '/home/albertapayments/public_html/customer/view/template/');
define('DIR_CONFIG', '/home/albertapayments/public_html/customer/system/config/');
define('DIR_CACHE', '/home/albertapayments/public_html/customer/system/storage/cache/');
define('DIR_DOWNLOAD', '/home/albertapayments/public_html/customer/system/storage/download/');
define('DIR_LOGS', '/home/albertapayments/public_html/customer/system/storage/logs/');
define('DIR_MODIFICATION', '/home/albertapayments/public_html/customer/system/storage/modification/');
define('DIR_UPLOAD', '/home/albertapayments/public_html/customer/system/storage/upload/');
define('DIR_CATALOG', '/home/albertapayments/public_html/customer/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', '13.59.208.236');
define('DB_USERNAME', 'inslocuser');
define('DB_PASSWORD', 'n@rayan!23');
define('DB_DATABASE', 'inslocdb');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
