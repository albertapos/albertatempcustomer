<?php
// Text
$_['text_footer'] 	= '&copy; ' . date('Y') . ' All Rights Reserved';
$_['text_version'] 	= '';